<?php
namespace Admin\Controller;
use Think\Controller;
header('content-type:text/html;charset=utf-8');
class TestController extends CommonController{
	public function _initialize(){
		parent::_initialize();
	}

	public function pj(){
		if (IS_POST) {
			$data['ProId']=$_POST['ProId'];
			$data['MemberId']=$_POST['MemberId'];
			$data['Class']=$_POST['Class'];
			$data['ClassScore']=$_POST['ClassScore'];
			$data['ServiceScore']=$_POST['ServiceScore'];
			$data['LogisticsScore']=$_POST['LogisticsScore'];
			$data['Content']=$_POST['Content'];
			$data['OrderId']=$_POST['OrderId'];
			$data['IsDelete']=0;
			$data['Label']='';
			$data['Integral']=0;
			$data['Image']='';
			if (M()->table('RS_ProductEvaluation')->add($data)) {
				$this->success('添加成功');
			}else{
				$this->error('添加失败');
			}
		}else{
			$pinfos=M()->table('RS_Product')->select();
			$this->assign('pinfos',$pinfos);
			$this->display();
		}
	}

	public function seng(){
		import("Vendor.Wechat.WXTemplate");
		$wxinfo=array('appid'=>'wxed2f2ef5e18e5423','appsecert'=>'b75711e17f2bcd266923254e85cb4206');
		$msg=new \WXTemplate($wxinfo);
		// var_dump($msg);
		$data=array(
			'touser'=>'o1e6cv18DEL1F87j8qqC5LFZ33I4',
			'template_id'=>'-R-s_sG19MBStzHyWqASJ1M4_WlDvXOG7mqsfCdcfeA',
			'first'=>array('value'=>'first','color'=>'#000000'),
			'remark'=>array('value'=>'remark','color'=>'#000000'),
			'content'=>array(
				'keyword1'=>array('value'=>'21111','color'=>'#000000'),
				'keyword2'=>array('value'=>'22222','color'=>'#000000'),
				'keyword3'=>array('value'=>'23333','color'=>'#000000')
				)
			);
		$res=$msg->sendTemplate($data);
		var_dump($res);
	}





}












?>
