<?php 
namespace Admin\Controller;
use Think\Controller;
/**
* 
*/
class PhoneController extends BaseController
{
	public $token;
	public $model;
	function _initialize()
	{
		$this->model=M();
	}


	public function index(){
		if (IS_POST) {
		}else{
			$now=date('Y-m-d 23:59:59',strtotime('-1 days'));
			$aweek=date('Y-m-d 00:00:00',strtotime('-8 days'));
			$weeknow=date('Y-m-d 23:59:59',strtotime('-8 days'));
			$tweek=date('Y-m-d 00:00:00',strtotime('-15 days'));
			$data_now=$this->model->table('RS_Order')->where("CreateDate BETWEEN '{$aweek}' and '{$now}'")->group("CONVERT(varchar(10),CreateDate,120)")->getField("CONVERT(varchar(10),CreateDate,120) as Days,SUM(Price) as Money,Count(OrderId) as ocount");
			// var_dump(M()->getlastsql());
			$data_last=$this->model->table('RS_Order')->where("CreateDate BETWEEN '{$tweek}' and '{$weeknow}'")->group("CONVERT(varchar(10),CreateDate,120)")->getField("CONVERT(varchar(10),CreateDate,120) as Days,SUM(Price) as Money,Count(OrderId) as ocount");
			$week=array();
			$weekname=array('日','一','二','三','四','五','六');
			for ($i=7; $i > 0; $i--) { 
				$today=date('Y-m-d',strtotime('-'.$i.' days'));
				$zz= '周'.$weekname[date('w',strtotime('-'.$i.' days'))];
				$DB=array();
				$DB['time']=$today;
				$DB['week']=$zz;
				if (array_key_exists($today, $data_now)) {
					$DB['money']=$data_now[$today]['Money'];
					$DB['count']=$data_now[$today]['ocount'];
				}else{
					$DB['money']=0;
					$DB['count']=0;
				}
				$week[]=$DB;
			}
			// var_dump($week);
			$lweek=array();
			for ($i=14; $i > 7; $i--) { 
				$today=date('Y-m-d',strtotime('-'.$i.' days'));
				$DB=array();
				$DB['time']=$today;
				if (array_key_exists($today, $data_last)) {
					$DB['money']=$data_last[$today]['Money'];
					$DB['count']=$data_last[$today]['ocount'];
				}else{
					$DB['money']=0;
					$DB['count']=0;
				}
				$lweek[]=$DB;
			}
			$char_week=array();
			$char_order=array();
			$char_money=array();
			$char_last_order=array();
			$char_last_money=array();
			foreach ($week as $wk) {
				$char_week[]=$wk['week'];
				$char_order[]=$wk['count'];
				$char_money[]=$wk['money'];
			}
			foreach ($lweek as $wk) {
				$char_last_order[]=$wk['count'];
				$char_last_money[]=$wk['money'];
			}
			$pagedata['char_week']=json_encode($char_week);
			$pagedata['char_order']=json_encode($char_order);
			$pagedata['char_money']=json_encode($char_money);
			$pagedata['char_last_order']=json_encode($char_last_order);
			$pagedata['char_last_money']=json_encode($char_last_money);
			//区域
			$areas=$this->model->query("SELECT am.AreaName as name,CONVERT(float(50),ISNULL(SUM(o.Price), 0),120) as value FROM RS_AreaManager am LEFT JOIN RS_AreaList al ON am.ID=al.AreaId LEFT JOIN RS_Store s ON s.province=al.Area LEFT JOIN RS_Order o ON o.stoken=s.stoken WHERE s.stoken<>'0' and s.IsCheck='1'GROUP BY am.AreaName");
			$anames=array();
			foreach ($areas as $ak=>$as) {
				if ($as['value']>0) {
					$anames[]=$as['name'];
				}else{
					unset($areas[$ak]);
				}
			}
			$pagedata['pie_data']=json_encode($areas);
			$pagedata['pie_x']=json_encode($anames);
			$this->assign($pagedata);
			$this->display();
		}

	}

	public function sales(){
		if (IS_POST) {
			
		}else{
			$now=date('Y-m-d 23:59:59',strtotime('-1 days'));
			$mon=date('Y-m-d 00:00:00',strtotime('-30 days'));
			$data_now=$this->model->table('RS_Order')->where("CreateDate BETWEEN '{$mon}' and '{$now}'")->group("CONVERT(varchar(10),CreateDate,120)")->getField("CONVERT(varchar(10),CreateDate,120) as Days,SUM(Price) as Money,Count(OrderId) as ocount");
			$time=array();
			$money=array();
			$count=array();
			for ($i=30; $i > 0; $i--) { 
				$today=date('m-d',strtotime('-'.$i.' days'));
				$time[]=$today;
				if (array_key_exists($today, $data_now)) {
					$money[]=$data_now[$today]['money'];
					$count[]=$data_now[$today]['ocount'];
				}else{
					$money[]=0;
					$count[]=0;
				}
			}
			$pagedata['money']=json_encode($money);
			$pagedata['time']=json_encode($time);
			$pagedata['count']=json_encode($count);
			$this->assign($pagedata);
			$this->display();
		}
	}

	public function stores(){
		if (IS_POST) {
			
		}else{
			$this->assign($pagedata);
			$this->display();
		}
	}

	

















}














 ?>