<?php
namespace Admin\Model;
use Think\Model;
class ProductImageModel extends Model{
	protected $tableName="ProductImage";
	protected $autoCheckFields = false;
}






 ?>
