<?php
namespace Admin\Model;
use Think\Model;
class ProductAttributeModel extends Model{
	protected $tableName="ProductAttribute";
}






?>
