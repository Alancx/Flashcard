<?php
namespace Seller\Controller;
use Think\Controller;
header('content-type:text/html;charset=utf-8');
class StoresController extends CommonController{
	public function _initialize(){
		parent::_initialize();
	}

	public function index(){
		if (IS_POST) {
			$sid=$_POST['sid'];
			if ($_POST['endtime']) {
				$where=" AND stoken='".$this->stoken."' AND Mercut=1 AND PayDate BETWEEN '".$_POST['strtime']."' AND '".$_POST['endtime']."'";
			}else{
				$where=" AND stoken='".$this->stoken."' AND Mercut=1";
			}
			$storeinfo=M()->table('RS_Store')->where("token='%s' and id='%s'",array($this->token,$sid))->find();
			// var_dump(M()->getlastsql());
			$Sorders=M()->query("SELECT SUM(Price-Freight) AS sallmoney,COUNT(OrderId) AS scount FROM RS_Order  WHERE Status in (4,10) AND PayName='XJ' AND Prostoken='".$storeinfo['stoken']."'".$where)[0];  //商户销售自家商品单据
			// echo M()->getlastsql();exit();
			$pagedata['cutinfo']=$Sorders;
			$pagedata['pageinfo']=array('sid'=>$sid);
			$pagedata['cutmoney']=$OnlineCut+$MonlineCut;
			$pagedata['stime']=date('Y-m-d H:i:s',$storeinfo['MercutDate']);
			$pagedata['storename']=$storeinfo['storename'];
			$pagedata['endtime']=$_POST['endtime'];
			// $pagedata['stime']=
			if ($_POST['type']=='cuted') {
				$Info['token']=$this->token;
				$Info['storeid']=$sid;
				$Info['allmoney']=$Sorders['sallmoney'];
				$Info['CreateDate']=date('Y-m-d H:i:s',time());
				$Info['stoken']=$this->stoken;
				//更新时间
				if ($_POST['endtime']) {
					$time=strtotime($_POST['endtime']);
					// $tempInfo=array('MercutDate',strtotime($_POST['endtime']));
					$newWhere=" AND PayDate BETWEEN '".$_POST['strtime']."' and '".$_POST['endtime']."'";
				}else{
					$time=time();
					// $tempInfo=array('MercutDate',time());
					$mewWhere="";
				}
				M()->startTrans();
				$sres=M()->table('RS_Store')->where('id=%d',$sid)->setField('MercutDate',$time);
				$ires=M()->table('RS_ToStoreinfo')->add($Info);
				$ores=M()->execute("UPDATE RS_Order SET Mercut=2 WHERE stoken='".$this->stoken."' AND Prostoken='".$storeinfo['stoken']."' AND Status in(4,10)".$newWhere);
				if ($sres && $ires && $ores) {
					M()->commit();
					echo json_encode('success');exit();
				}else{
					$this->LOGS("sres=$sres && ires=$ires && ores=$ores_____".M()->getlastsql());
					M()->rollback();
					echo json_encode('error');exit();
				}
			}
		}else{
			$pagedata['pageinfo']=false;
		}
		$stores=M()->table('RS_Store')->where("token='%s' and IsCheck='%s' and stoken<>'%s'",array($this->token,'1',$this->stoken))->select();
		foreach ($stores as &$st) {
			$st['ctime']=date('Y-m-d H:i:s',$st['MercutDate']);
		}
		$pagedata['jsondata']=json_encode($stores);
		$pagedata['stores']=$stores;
		$this->assign($pagedata);
		$this->display();
	}

	/**
	 * 查看明细
	 */
	public function getmore(){
		$sid=$_POST['sid'];
		$storeinfo=M()->table('RS_Store')->where('id=%d',$sid)->find();
		if ($_POST['etime']) {
			$where=" AND stoken='".$this->stoken."' AND Mercut=1 AND PayDate BETWEEN '".$_POST['stime']."' AND '".$_POST['etime']."'";
		}else{
			$where=" AND stoken='".$this->stoken."' AND Mercut=1";
		}
		$Sorders=M()->query("SELECT OrderId,Price,Freight,MemberId,RecevingName,Count,CONVERT(varchar(100),PayDate,120) as PayDate FROM RS_Order  WHERE Status in (4,10) AND PayName='XJ' AND Prostoken='".$storeinfo['stoken']."'".$where);  //商户销售自家商品单据
		// echo M()->getlastsql();exit();
		if (count($Sorders)>0) {
			echo json_encode(array('status'=>'success','data'=>$Sorders));
		}else{
			echo json_encode(array('status'=>'error','info'=>'没有订单.'));
		}
	}

	/**
	 * 商户信息设置
	 */
	public function sinfoset(){
		if (IS_POST) {
			
		}else{
			$binfo=M()->table('RS_MerchantBank')->where("token='%s' and stoken='%s'",array($this->token,$this->stoken))->find();
			$pagedata['binfo']=$binfo;
			if ($binfo) {
				$pagedata['isold']=1;
			}else{
				$pagedata['isold']=0;
			}
			$this->assign($pagedata);
			$this->display();
		}
	}

	/**
	 * 发验证码
	 */
	public function sendmsg(){
		$type=$_POST['type'];
		$str='0123456789';
		switch ($type) {
			case 'bankverify':
				$code=substr(str_shuffle($str), -6,6);
				$msg['content']='您的验证码为：'.$code;
				$msg['mobiles']=$_POST['tel'];
				break;
			
			default:
				# code...
				break;
		}
		$this->SendMessage($msg);
		$res['status']='success';
		$res['info']=$code;
		echo json_encode($res);
	}

	/**
	 * 保存银行卡信息
	 */
	public function savebanks(){
		$data=$_POST;
		unset($data['isold']);
		if ($_POST['isold']=='1') {
			//更新信息
			if (M()->table('RS_MerchantBank')->where("token='%s' and stoken='%s'",array($this->token,$this->stoken))->save($data)) {
				$msg['status']='success';
			}else{
				$msg['status']='error';
				$this->LOGS('银行卡信息更新失败--->>>'.M()->getlastsql());
			}
		}else{
			$data['token']=$this->token;
			$data['stoken']=$this->stoken;
			if (M()->table('RS_MerchantBank')->add($data)) {
				$msg['status']='success';
			}else{
				$msg['status']='error';
				$this->LOGS('银行卡信息添加失败--->>>'.M()->getlastsql());
			}
		}
		echo json_encode($msg);
	}

	/**
	 * 修改基本信息
	 */
	public function changestinfo(){
		if (IS_POST) {
			$data=$_POST;
			$data['slang']=$_POST['lang']>0?$_POST['lang']:360+$_POST['lang']; //搜索经度
			if (M()->table('RS_Store')->where("token='%s' and stoken='%s'",array($this->token,$this->stoken))->save($data)) {
				$this->success('修改成功');
			}else{
				$this->LOGS("门店信息修改失败--->>>".M()->getlastsql());
				$this->error('修改失败');
			}
		}else{
			$sinfo=M()->table('RS_Store')->where("token='%s' and stoken='%s'",array($this->token,$this->stoken))->find();
			$pagedata['sinfo']=$sinfo;
			$this->assign($pagedata);
			$this->display();
		}
	}

	/**
	 * 配送费用设置 2017-05-14
	 */
	public function mercutinfo(){
		if (IS_POST) {
			$update=array();
			$update['PsPrice']=$_POST['PsPrice'];
			$update['PsGet']=$_POST['PsGet'];
			if (M()->table('RS_Store')->where("id=%d",$_POST['id'])->setField($update)) {
				$msg['status']='success';
			}else{
				$msg['status']='error';
				$msg['info']='处理失败';
			}
			echo json_encode($msg);
		}else{
			$store=M()->table('RS_Store')->where("token='%s' and stoken='%s'",array($this->token,$this->stoken))->select();
			// var_dump(M()->getlastsql());exit();
			$pagedata['store']=$store;
			$this->assign($pagedata);
			$this->display();
		}
	}

	/**
	 * 账户提现  2017-05-14
	 */
	public function CashManager(){
		if (IS_POST) {
			$Param=$_POST;
		}else{
			$Param=$_GET;
		}
		unset($Param['v']);
		unset($Param['p']);
		$whereStr="token='{$this->token}' and stoken='{$this->stoken}'";
		if ($Param && count($Param)>0) {
			if ($Param['Status']) {
				$whereStr.=" and Status='{$Param['Status']}'";
			}
			if ($Param['StartDate'] && $Param['EndDate']) {
				$whereStr.=" and CreateDate BETWEEN '{$Param['StartDate']}' and '{$Param['EndDate']}'";
			}
		}
		$pagedata['Money']=M()->table('RS_Store')->where("token='%s' and stoken='%s'",array($this->token,$this->stoken))->getField("Money");
		$count=M()->table('RS_MerCutDetail')->where($whereStr)->count();
		// var_dump(M()->getlastsql());
		$page = new \Think\Page($count,20,$Param);
		$lists= M()->table('RS_MerCutDetail')->where($whereStr)->field("ID,Money,CONVERT(varchar(20),CreateDate,120) as CreateDate,IdCard,IdName,GetName,tel,CONVERT(varchar(20),ExecDate,120) as ExecDate,(CASE Status WHEN '0' THEN '待处理' WHEN '1' THEN '已处理' END) AS Status,Status as Astu")->limit($page->firstRow.','.$page->listRows)->order('CreateDate desc')->select();
		// var_dump(M()->getlastsql());
		$pagedata['Param']=$Param;
		$pagedata['lists']=$lists;
		$pagedata['page']=$page->show();
		$this->assign($pagedata);
		$this->display();
	}

	/**
	 * 提现处理  2017-05-14
	 */
	public function getmoney(){
		if (IS_POST) {
			$IdInfo=M()->table('RS_MerchantBank')->where("stoken='%s' and token='%s' and IsCheck='1'",array($this->stoken,$this->token))->find();
			if ($IdInfo && $IdInfo['IdCard'] && $IdInfo['IdName'] && $IdInfo['tel'] && $IdInfo['BankName']) {
				$money=$_POST['money'];
				$RecoreData=array();
				$RecoreData['Money']=$money;
				$RecoreData['stoken']=$this->stoken;
				$RecoreData['IdCard']=$IdInfo['IdCard'];
				$RecoreData['IdName']=$IdInfo['BankName'];
				$RecoreData['IdType']=$IdInfo['IsOpen'];
				$RecoreData['GetName']=$IdInfo['IdName'];
				$RecoreData['tel']=$IdInfo['tel'];
				$RecoreData['token']=$this->token;
				M()->startTrans();
				$sres=M()->table('RS_Store')->where("token='%s' and stoken='%s'",array($this->token,$this->stoken))->setDec('Money',$money);
				$mres=M()->table('RS_MerCutDetail')->add($RecoreData);
				if ($sres && $mres) {
					M()->commit();
					$msg['status']='success';
					$RecoreData['Status']='待处理';
					$RecoreData['CreateDate']=date('Y-m-d H:i:s',time());
					$RecoreData['ID']=$mres;
					$msg['data']=$RecoreData;
				}else{
					M()->rollback();
					$msg['status']='error';
					$msg['info']='处理失败';
				}
			}else{
				$msg['status']='error';
				$msg['info']='银行账户信息不全，请完善银行账户信息后申请提现';
			}
			echo json_encode($msg);
		}
	}

	/**
	 * 取消申请  2017-05-14
	 */
	public function cancelMoney(){
		$ID=$_POST['ID'];
		$minfo=M()->table('RS_MerCutDetail')->where("ID=%d",$ID)->find();
		M()->startTrans();
		$mres=M()->table('RS_MerCutDetail')->where("ID=%d",$ID)->delete();
		$sres=M()->table('RS_Store')->where("token='%s' and stoken='%s'",array($this->token,$this->stoken))->setInc('Money',$minfo['Money']);

		if ($mres && $sres) {
			M()->commit();
			$msg['status']='success';
			$msg['Money']=M()->table("RS_Store")->where("token='%s' and stoken='%s'",array($this->token,$this->stoken))->getField("Money");
		}else{
			M()->rollback();
			$msg['status']='error';
			$msg['info']='处理失败';
		}
		echo json_encode($msg);
	}

	/**
	 * 账户金额变动记录   2017-05-14
	 */
	public function storemoney(){
		if (IS_POST) {
			
		}else{

		}
		$whereStr="token='{$this->token}' and stoken='{$this->stoken}'";
		$count=M()->table('RS_StoreMoneyManager')->where($whereStr)->count();
		$page = new \Think\Page($count,20);
		$lists= M()->table('RS_StoreMoneyManager')->where($whereStr)->field("CONVERT(varchar(20),CreateDate,120) as CreateDate,CONVERT(float(53),ISNULL(Money,0),120) as Money,(CASE Type WHEN 'add' THEN '收入' WHEN 'less' THEN '支出' END) as Type,(CASE Useage WHEN 'XS' THEN '销售结算' WHEN 'YL' THEN '引流结算' WHEN 'JS' THEN '提现支出' WHEN 'PS' THEN '配送员提现' END) as Useage")->limit($page->firstRow.','.$page->listRows)->order("CreateDate desc")->select();
		// var_dump(M()->getlastsql());
		$pagedata['lists']=$lists;
		$pagedata['page']=$page->show();
		$pagedata['MoneyInfo']=M()->table('RS_Store')->where($whereStr)->find();
		$this->assign($pagedata);
		$this->display();
	}

	/**
	 * 核销员添加管理
	 */
	public function cancel(){
		if (IS_POST) {
			
		}else{
			$count=M()->table('RS_Cancel')->where("stoken='%s'",$this->stoken)->count();
			$page = new \Think\Page($count,20);
			$lists=M()->table('RS_Cancel')->where("stoken='%s'",$this->stoken)->field("id,CONVERT(varchar(20),CreateDate,120) as CreateDate,username")->limit($page->firstRow.','.$page->listRows)->select();
			$pagedata['page']=$page->show();
			$pagedata['lists']=$lists;
			$this->assign($pagedata);
			$this->display();
		}
	}

	/**
	 * 删除核销员
	 */
	public function delcancel(){
		$id=$_GET['id'];
		if (M()->table('RS_Cancel')->where('id=%d',$id)->delete()) {
			$this->success('删除成功');
		}else{
			$this->error('删除失败');
		}
	}

	/**
	 * 更新验证码
	 */
	public function getcancelverify(){
		$verify=$this->getStr(1,3,false);
		$time=date('Y-m-d H:i:s',time()+3600);
		if (M()->table('RS_Store')->where("token='%s' and stoken='%s'",array($this->token,$this->stoken))->setField(array("verify"=>$verify,'verify_time'=>$time))) {
			$msg['status']='success';
			$msg['verify']=$verify;
		}else{
			$msg['status']='error';
		}
		// var_dump(M()->getlastsql());exit();
		// var_dump($_SERVER);
		echo json_encode($msg);
	}
	/**
	 * 二维码输出
	 */
	public function getCancelQr(){
		ob_clean();
		vendor('PHPQR.phpqrcode');
		$level="L";
		$size=4;
		$url='https://'.$_SERVER['HTTP_HOST'].U('Admin/Base/addCancel').'?type=1&stoken='.$this->stoken;
		\QRcode::png($url,false,$level,$size,'2');
	}


}
