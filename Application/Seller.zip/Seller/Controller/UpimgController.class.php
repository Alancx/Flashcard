<?php
namespace Seller\Controller;
use Think\Controller;
class UpimgController extends Controller{
	public $ImgUrl;
	public function index(){
		if (IS_POST) {
			$upload=new \Think\Upload();
			$upload->maxSize=3145728;
			$upload->savePath='./Uoloads/';
			$upload->exts=array('jpg','png','jpeg','gif');
			// $upload->thumb=true;
			// $upload->thumbMaxWidth='200';
			// $upload->thumbMaxHeight='200';
			// $upload->thumbRemoveOrigin=false;
			// $upload->
			$info=$upload->uploadOne($_FILES['img']);
			if (!$info) {
				$this->error($upload->getError());
			}else{
				// if ($_POST['tumb']=='true') {
				// 	$img=new \Think\Image();
				// 	$img->open('./Uploads'.substr($info['savepath'], 1).$info['savename']);
				// 	$img->thumb(150,150)->save('./Uploads'.substr($info['savepath'], 1)."thumb_".$info['savename']);
				// 	$this->assign('tumbimg','Uploads'.substr($info['savepath'], 1)."thumb_".$info['savename']);
				// }
				$ImgUrl='/Upload'.substr($info['savepath'],1).$info['savename'];
				// $img=$img=substr($upload->savePath.$info['savename'],0);
				// var_dump($info);
				// var_dump($img);
				// var_dump($ImgUrl);
				$image = new \Think\Image();
				$image->open('.'.$ImgUrl);
				$image->thumb(200,200)->save('./Upload/'.$info['savepath'].'thumb_'.$info['savename']);
				$this->assign('imgurl',$ImgUrl);
				$this->display();
			}
			// var_dump($_FILES);
		}else{
			// $this->assign('imgurl','0');
			// var_dump($this->ImgUrl);
			$this->display();
		}
	}

	public function editpro(){
		if (IS_POST) {
			$upload=new \Think\Upload();
			$upload->maxSize=3145728;
			$upload->savePath='./Uoloads/';
			$upload->exts=array('jpg','png','jpeg','gif');
			$info=$upload->uploadOne($_FILES['img']);
			if (!$info) {
				$this->error($upload->getError());
			}else{
				// if ($_POST['tumb']=='true') {
				// 	$img=new \Think\Image();
				// 	$img->open('./Uploads'.substr($info['savepath'], 1).$info['savename']);
				// 	$img->thumb(150,150)->save('./Uploads'.substr($info['savepath'], 1)."thumb_".$info['savename']);
				// 	$this->assign('tumbimg','Uploads'.substr($info['savepath'], 1)."thumb_".$info['savename']);
				// }
				$ImgUrl="/Upload".substr($info['savepath'], 1).$info['savename'];
				if ($_POST['logo']=='ProLogoImg') {
					$image = new \Think\Image();
					$image->open('.'.$ImgUrl);
					$image->thumb(200,200)->save('./Upload/'.$info['savepath'].'thumb_'.$info['savename']);
				}
				$this->assign('imgurl',$ImgUrl);
				$this->display();
			}
			// var_dump($_FILES);
		}else{
			// $this->assign('imgurl',$this->ImgUrl);
			// var_dump($this->ImgUrl);
			$this->display();
		}
	}


	public function saveimg(){
			$upload=new \Think\Upload();
			$upload->maxSize=3145728;
			$upload->savePath='./Uoloads/';
			$upload->exts=array('jpg','png','jpeg','gif');
			$info=$upload->upload();
			if (!$info) {
				$this->error($upload->getError());
			}else{
				$img="/Upload".substr($info['file']['savepath'], 1).$info['file']['savename'];
				echo json_encode($img);
			}
	}


	public function home(){
		if (IS_POST) {
			$upload=new \Think\Upload();
			$upload->maxSize=3145728;
			$upload->savePath='./Home/';
			$upload->exts=array('jpg','png','jpeg','gif');
			$info=$upload->uploadOne($_FILES['img']);
			if (!$info) {
				$this->error($upload->getError());
			}else{
				// if ($_POST['tumb']=='true') {
				// 	$img=new \Think\Image();
				// 	$img->open('./Uploads'.substr($info['savepath'], 1).$info['savename']);
				// 	$img->thumb(150,150)->save('./Uploads'.substr($info['savepath'], 1)."thumb_".$info['savename']);
				// 	$this->assign('tumbimg','Uploads'.substr($info['savepath'], 1)."thumb_".$info['savename']);
				// }
				$ImgUrls="/Upload".substr($info['savepath'], 1).$info['savename'];
				$this->assign('imgurl',$ImgUrls);
				$this->display();
			}
			// var_dump($_FILES);
		}else{
			// $this->assign('imgurl',$this->ImgUrl);
			// var_dump($this->ImgUrl);
			$this->display();
		}
	}
	public function spceil(){
		if (IS_POST) {
			$upload=new \Think\Upload();
			$upload->maxSize=3145728;
			$upload->savePath='./spceil/';
			$upload->exts=array('jpg','png','jpeg','gif');
			$info=$upload->uploadOne($_FILES['img']);
			if (!$info) {
				$this->error($upload->getError());
			}else{
				// if ($_POST['tumb']=='true') {
				// 	$img=new \Think\Image();
				// 	$img->open('./Uploads'.substr($info['savepath'], 1).$info['savename']);
				// 	$img->thumb(150,150)->save('./Uploads'.substr($info['savepath'], 1)."thumb_".$info['savename']);
				// 	$this->assign('tumbimg','Uploads'.substr($info['savepath'], 1)."thumb_".$info['savename']);
				// }
				$ImgUrls="/Upload".substr($info['savepath'], 1).$info['savename'];
				// var_dump($ImgUrls);exit();
				// $image=new \Think\Image();
				// $image->open('.'.$ImgUrls);
				// $image->thumb(640,640)->save('./Upload/'.$info['savepath'].$info['savename']);
				$this->assign('imgurl',$ImgUrls);
				$this->display();
			}
			// var_dump($_FILES);
		}else{
			// $this->assign('imgurl',$this->ImgUrl);
			// var_dump($this->ImgUrl);
			$this->display();
		}
	}
	public function classimg(){
		if (IS_POST) {
			$upload=new \Think\Upload();
			$upload->maxSize=3145728;
			$upload->savePath='./Class/';
			$upload->exts=array('jpg','png','jpeg','gif');
			$info=$upload->uploadOne($_FILES['img']);
			if (!$info) {
				$this->error($upload->getError());
			}else{
				// if ($_POST['tumb']=='true') {
				// 	$img=new \Think\Image();
				// 	$img->open('./Uploads'.substr($info['savepath'], 1).$info['savename']);
				// 	$img->thumb(150,150)->save('./Uploads'.substr($info['savepath'], 1)."thumb_".$info['savename']);
				// 	$this->assign('tumbimg','Uploads'.substr($info['savepath'], 1)."thumb_".$info['savename']);
				// }
				$ImgUrls="/Upload".substr($info['savepath'], 1).$info['savename'];
				$image = new \Think\Image();
				$image->open('.'.$ImgUrls);
				$image->thumb(100,100)->save('./Upload/'.$info['savepath'].'thumb_'.$info['savename']);
				$this->assign('imgurl',$ImgUrls);
				$this->display();
			}
			// var_dump($_FILES);
		}else{
			// $this->assign('imgurl',$this->ImgUrl);
			// var_dump($this->ImgUrl);
			$this->display();
		}
	}
}





 ?>
