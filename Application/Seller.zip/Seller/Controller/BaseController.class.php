<?php
namespace Seller\Controller;
use Think\Controller;
class BaseController extends Controller{

	function _empty(){
		header("HTTP/1.0 404 NotFound");
		$this->display('Common:404');
	}

	public function checkStore(){
		exit();
		$id=$_GET['id'];
		if ($_GET['code']) {
			$code=$_GET['code'];
			// header("loaction:https://api.weixin.qq.com/sns/oauth2/access_token?appid=wx8d5a5c2f1538e6c0&secret=99f16188336fc16d7df795893e175576&code=".$code."&grant_type=authorization_code");
			$resinfo=file_get_contents("https://api.weixin.qq.com/sns/oauth2/access_token?appid=".C('WXAPPID')."&secret=".C('WXAPPSECRET')."&code=".$code."&grant_type=authorization_code");
			$uinfo=json_decode($resinfo,true);
			$token=$this->get_access_token();
			$user=file_get_contents("https://api.weixin.qq.com/cgi-bin/user/info?access_token=".$token."&openid=".$uinfo['openid']."&lang=zh_CN");
			$user=json_decode($user,true);
			echo "你好 <span style='color:red'><b>".$user['nickname']."</b></span> 我拿到了你的个人信息 <img src='".$user['headimgurl']."'>";

		}else{
			$redirect_uri=C('ADMINURL').U('Base/checkStore').'?id='.$id;
			header("location:https://open.weixin.qq.com/connect/oauth2/authorize?appid=".C('WXAPPID')."&redirect_uri=".urlencode($redirect_uri)."&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect");
		}


	}

	public function get_access_token(){
	    $data=file_get_contents("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=".C('WXAPPID')."&secret=".C('WXAPPSECRET'));
	    $content=json_decode($data,true);
	    $token=$content['access_token'];
	    return $token;
	}

	public function MSL($tb){
		return M($tb,C('MYSQL')['DB_PREFIX'],'MYSQL');
	}

	public function SRV($tb){
		return false;
	}
	
	 //基础数据库读取
	 public function BM($tableName)
	 {
		return M($tableName,C('DB_BASE')['DB_PREFIX'],'DB_BASE');
	 }
	 
	 //用户数据库读取
	 public function UM($tableName)
	 {
		return M($tableName,C('DB_USER')['DB_PREFIX'],'DB_USER');
	 }

	 //仓库数据库读取
	 public function WM($tableName)
	 {
		return M($tableName,C('DB_USER')['DB_PREFIX'],'DB_WAREHOUSE');
	 }

//短信发送-基于腾信公司接口
	public function SendMessage($messageData)
	{

		$timeStamp=date('Y-m-d H:i:s',time());

		$SMData=array(
			'username'=>C('SMS_USERNAME'),
			'password'=>md5(C('SMS_PASSWORD').$timeStamp),
			'mobiles'=>$messageData['mobiles'],
			'content'=>C('SMS_SIGN').$messageData['content'],
			'f'=>'1',
			'timestamp'=>$timeStamp,
		);

		$SendURL=C('SMS_SENDURL').http_build_query($SMData);
		// file_put_contents('temp.json', $SendURL,FILE_APPEND);
		$res=$this->httpGet($SendURL);
		$this->LOGS($SendURL.'---结果'.$res);
		// file_put_contents('temp.json', $res,FILE_APPEND);
		$resArray=json_decode($res,true);
	}


		//GET请求
	public function httpGet($url)
	{
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_TIMEOUT, 500);

		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, true);
		curl_setopt($curl, CURLOPT_URL, $url);

		$res = curl_exec($curl);
		//$res=curl_errno($curl);
		curl_close($curl);

		return $res;
	}


	/**
	 * 用户操作记录log
	 */
	public function LOGS($desc='',$controller=CONTROLLER_NAME,$function=ACTION_NAME){
		$filename=date('Y-m-d',time());
		$logfile=str_replace('\\','/',strrev(substr(strrev(dirname(__FILE__)),10))).'logs/';
		if (!is_dir($logfile)) {
			mkdir($logfile,777);
		}
		$logfile=$logfile.$filename.'.txt';
		// var_dump($logfile);exit;
		$content='操作定位:'.$controller.'/'.$function.'::::'.$desc.'::::::操作日期:::::::'.date('Y-m-d H:i:s',time()).PHP_EOL;
		file_put_contents($logfile,$content,FILE_APPEND);
	}

	/**
	 * 同兴支付通知信息
	 */
	public function Invonotify(){
		$data=$_POST;
		$this->LOGS('交易信息--->>>'.json_encode($_POST));
		if ($data['dealCode']=='10000') {
			$cid=$data['ext1'];
			$update=array();
			$update['IsPay']='1';
			$update['OrderId']=$data['orderNo'];
			$update['txOrderNo']=$data['txOrderNo'];
			$update['bankOrderNo']=$data['bankOrderNo']?$data['bankOrderNo']:'';
			$update['LastUpdateDate']=date('Y-m-d H:i:s',time());
			$update['Status']='2';
			if (M()->table('RS_ProductInWarehouse')->where("InWarehouseId='%s' and Status='-1'",$cid)->save($update)) {
				$param=array();
				$param['merchantNo']='TX0001455';
				$param['dealResult']='SUCCESS';
				$sign=$this->lvs_sign($param);
				$param['sign']=$sign;
				$url='http://api.tongxingpay.com/txpayApi/offLine';
				$this->LOGS('反馈同兴信息--->>'.json_encode($param));
				$this->postXmlCurl($param,$url);
			}else{
				$this->LOGS(M()->getlastsql());
			}
		}
	}


	/**
     * 签名
     */
    private function lvs_sign($data){
        ksort($data);
        $str=urldecode(http_build_query($data));
        $str=$str.'d80efe63192b4b7ebf9a30d78075b8fa';
        // var_dump($str);exit();
        // $this->LOGS($str);
        $sign=strtoupper(md5($str));
        return $sign;
    }








    /**
     * 以post方式提交xml到对应的接口url
     * 
     * @param string $xml  需要post的xml数据
     * @param string $url  url
     * @param bool $useCert 是否需要证书，默认不需要
     * @param int $second   url执行超时时间，默认30s
     * @throws WxPayException
     */
    public function postXmlCurl($xml, $url, $second = 30)
    {       
        // var_dump($xml,$url);exit();
        $ch = curl_init();
        //设置超时
        curl_setopt($ch, CURLOPT_TIMEOUT, $second);
        
        //如果有配置代理这里就设置代理
        curl_setopt($ch,CURLOPT_URL, $url);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);//严格校验
        //设置header
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        //要求结果为字符串且输出到屏幕上
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    
        //post提交方式
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
        //运行curl
        $data = curl_exec($ch);
        //返回结果
        // var_dump($data);exit();
        if($data){
            curl_close($ch);
            $this->LOGS($data);
            return $data;
        } else { 
            $error = curl_errno($ch);
            curl_close($ch);
            if ($error!='0') {
                $res['status']=false;
                $res['info']="curl出错，错误码:$error";
            }else{
                $res='通讯成功，对方无响应';
            }
            return $res;
        }
    }
}


 ?>
