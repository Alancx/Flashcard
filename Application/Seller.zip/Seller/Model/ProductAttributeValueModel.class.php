<?php
namespace Seller\Model;
use Think\Model;
class ProductAttributeValueModel extends Model{
	protected $tableName="ProductAttributeValue";
	protected $autoCheckFields = false;
}






 ?>
