<?php
namespace Seller\Model;
use Think\Model;
class ProductAttributeModel extends Model{
	protected $tableName="ProductAttribute";
}






?>
